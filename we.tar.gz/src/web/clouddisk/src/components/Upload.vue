<template>
  <el-upload class="upload" drag action="/upload" multiple :before-upload="beforeUpload" :data="dt">
    <i class="el-icon-upload"></i>
    <div class="el-upload__text">
      Drag files here
      <em>or Click to Upload</em>
    </div>
    <div class="el-upload__tip" slot="tip">file size less than 128Mb</div>
  </el-upload>
</template>

<script>
import SparkMD5 from "spark-md5";

export default {
  name: "Upload",
  computed: {
    dt() {
      return {
        info: "not ready...",
      };
    },
  },
  methods: {
    beforeUpload(file) {
      var sizeok = file.size / 1024 / 1024 < 128;
      if (sizeok) {
        var freader = new FileReader();
        var spark = new SparkMD5.ArrayBuffer();
        var md5;
        var user = window.sessionStorage["user"];
        var size = file.size;
        var filename = file.name;
        debugger;

        freader.readAsArrayBuffer(file);
        freader.onload = function (e) {
          spark.append(e.target.result);
          md5 = spark.end();
          if (user && md5 && size && filename) {
            this.info = [user, filename, md5, size].join("|");
            console.log(this.info);
          } else {
            alert("something wrong...");
            return false;
          }
        };
      } else {
        alert("file size exceed 512Mb");
        return false;
      }
    },
  },
};
</script>