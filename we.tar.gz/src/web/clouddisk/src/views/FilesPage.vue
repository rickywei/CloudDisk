

<template>
  <el-tabs v-model="activeName" @tab-click="refresh">
    <el-tab-pane label="upload" name="first">
      <Upload />
    </el-tab-pane>
    <el-tab-pane label="myfiles" name="second">
      <MyFiles />
    </el-tab-pane>
    <el-tab-pane label="sharedfiles" name="third">
      <SharedFiles />
    </el-tab-pane>
  </el-tabs>
</template>



<script>
import Upload from "@/components/Upload.vue";
import MyFiles from "@/components/MyFiles.vue";
import SharedFiles from "@/components/SharedFiles.vue";

export default {
  name: "FilesPage",
  components: {
    Upload,
    MyFiles,
    SharedFiles,
  },
  data() {
    return {
      activeName: "first",
      tableData: [],
    };
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    refresh(tab) {
      if (tab.label == "myfiles") {
        this.axios({
          method: "post",
          url: "https://run.mocky.io/v3/85aa4eca-e7aa-4787-90b7-ccf072e85037",
          data: {
            user: window.sessionStorage["user"],
            token: window.sessionStorage["token"],
          },
        }).then((res) => {
          this.tableData = res.data;
          console.log("fukc");
          console.log(this.tableData);
          if (res.status == 200) {
            if (res.data.code == "000") {
              this.$router.push({ path: "/FilesPage" });
            } else {
              alert("login failed, please check your account and passewd");
            }
          } else {
            alert("login failed");
          }
        });
      }
    },
  },
};
</script>