<template>
  <div id="registerForm">
    <el-form :label-position="labelPosition" label-width="80px" :model="registerData">
      <el-form-item label="user">
        <el-input v-model="registerData.user"></el-input>
      </el-form-item>
      <el-form-item label="passwd">
        <el-input v-model="registerData.passwd"></el-input>
      </el-form-item>
      <el-form-item label="phone">
        <el-input v-model="registerData.passwd"></el-input>
      </el-form-item>
      <el-form-item label="email">
        <el-input v-model="registerData.passwd"></el-input>
      </el-form-item>
    </el-form>
    <el-button type="success" round @click="register">Register</el-button>
  </div>
</template>

<script>
export default {
  name: "RegisterPage",
  data() {
    return {
      labelPosition: "left",
      registerData: {
        user: "",
        passwd: "",
      },
    };
  },
  methods: {
    register() {
      // console.log("register...", this.registerData.user, this.registerData.passwd);
      this.axios({
        method: "post",
        url: "/register",
        data: {
          username: this.registerData.user,
          password: this.registerData.passwd,
        },
      }).then((res) => {
        if (res.status == 200) {
          if (res.data.code == "000") {
            this.$router.push({ path: "/login" });
          } else {
            alert("register failed, please check your account and passewd");
          }
        } else {
          alert("register failed");
        }
      });
    },
  },
};
</script>
